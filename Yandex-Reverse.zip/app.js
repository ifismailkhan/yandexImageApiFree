const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const axios = require('axios'); // Add this line

const app = express();
const port = 3000;

app.use(cors()); // Enable CORS for all routes
app.use(bodyParser.json());

// Define the route for the 'get images' API
app.post('/get-images', async (req, res) => {
  try {
    // Get the text from the request body
    const searchText = req.body.text;

    // Make a request to the provided API
    const apiResponse = await axios.get('https://yandex.com/images/search', {
      params: {
        tmpl_version: req.body.tmpl_version,
        format: req.body.format,
        request: JSON.stringify(req.body.request),
        yu: req.body.yu,
        lr: req.body.lr,
        p: req.body.p,
        rpt: req.body.rpt,
        serpListType: req.body.serpListType,
        serpid: req.body.serpid,
        text: searchText,
        uinfo: req.body.uinfo,
      },
    });

    // Send the response back to the client
    res.json(apiResponse.data);
  } catch (error) {
    // Handle errors
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
